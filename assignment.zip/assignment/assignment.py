#A function that stores when to buy
def when_to_buy(prices):


# we start with an empty list to store days to buy
    days_to_buy = []

    # we start with an empty list to store days to buy
    days_to_sell = []

    #let find out length of the prices stored in a list
    n = len(prices)

    for i in range(1, n):
        # we check if the current price is less than the previous day i.e a dip in the market, then we should consider the opportunity to buy.
        if prices[i] < prices[i - 1]:
            days_to_buy.append(i)
        # If the price is higher than previous day, we should consider selling.
        if prices[i] > prices[i - 1]:
            days_to_sell.append(i)

    # let's create an empty list that stores a tuple that matches days to buy and days to sell
    trading_periods = []
    # we initialise variable i and J to get the indices of both days to buy and sell
    i = 0
    j = 0

    #A loop to create a list that stores a tuple of matching days to buy and sell
    while i < len(days_to_buy) and j < len(days_to_sell):
        if days_to_buy[i] < days_to_sell[j]:
            trading_periods.append((days_to_buy[i], days_to_sell[j]))
            i += 1
        else:
            j += 1
#A loop that generates the result
    for x, y in trading_periods:
        print(f"buy on day {x}, sell on day{y} ")

    return ""



prices = [45, 20, 30, 35, 32, 30, 89, 40, 45, 52]
print(when_to_buy(prices))



"""
    Question 2:
    Let's find the optimal stock plan given low-risk and high-risk values.


        low_risk: contains a list of low-risk values for each week.
        high_risk: contains a list of high-risk values for each week.

    Returns:
        The maximum achievable total value.
    """

def optimal_stock_plan(low_risk, high_risk):


    n = len(low_risk)
    # generate a table dynamically
    dp = [0] * (n + 1)

    for i in range(1, n + 1):
        # Consider low-risk choice
        dp[i] = max(dp[i], dp[i - 1] + low_risk[i - 1])

        # Consider high-risk choice if previous week was zero-risk
        if i > 1 and dp[i - 2] == 0:
            dp[i] = max(dp[i], dp[i - 2] + high_risk[i - 1])

    return dp[-1]